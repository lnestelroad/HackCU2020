// This file is where all of the javascript will live for the index.html file.

// Author: Liam Nestlroad
// Version 1.0

function linkCheck(){
    alert("All good!")
}